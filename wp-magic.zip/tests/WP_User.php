<?php

class WP_User
{
  function __call($name, $arguments) {}
}
