<?php

class WP_Error
{
  function __call($name, $arguments) {}
}
